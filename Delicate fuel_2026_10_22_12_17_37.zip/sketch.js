<!DOCTYPE html">
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cloud Design</title>

    <style>
        body {
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
            background: linear-gradient(
                to bottom,
                #2196f3,
                #81d4fa,
                #e1f5fe
            );
        }

        .cloud {
            position: relative;
            width: 200px;
            height: 60px;
            background: white;
            border-radius: 100px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
            animation: float 3s ease-in-out infinite;
        }

        .cloud::before {
            content: "";
            position: absolute;
            width: 100px;
            height: 100px;
            background: white;
            border-radius: 50%;
            top: -50px;
            left: 25px;
        }

        .cloud::after {
            content: "";
            position: absolute;
            width: 80px;
            height: 80px;
            background: white;
            border-radius: 50%;
            top: -35px;
            right: 20px;
        }

        @keyframes float {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-20px);
            }
        }

        h1 {
            position: absolute;
            top: 65%;
            color: white;
            font-family: Arial, sans-serif;